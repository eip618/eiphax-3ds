!!! boot.firm is the SafeB9Sinstaller. Once you have used it to install b9s successfully, you should delete it, and move boot.firm from the /luma folder onto the root folder. 

Your device will only boot to SafeB9Sinstaller until you do this. !!!

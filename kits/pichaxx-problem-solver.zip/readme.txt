!!! You must copy the corresponding *.bin file from the otherapps_with_CfgS folder for your console to the SD root,
and rename it to otherapp.bin.

The exploit will fail without it. !!!
